"""Platform-neutral task/session bridges.

The public Codex App calls are injected into :class:`CodexAppBridge`; this
package never imports or fabricates the desktop tool implementation.
"""

from dataclasses import dataclass, field
import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

from ..paths import ProjectPaths
from ..workflow_gate import (
    require_capability_contract,
    require_entry,
    require_child_origin,
)
from ..diagnostics import validate_child_session_binding
from ..models import WorkerProfile


class ProviderUnavailable(RuntimeError):
    """A provider cannot safely create or continue a task."""


class ProviderPending(RuntimeError):
    """A provider returned a pending task handle without a real task id."""


_PROVIDER_ACTIONS = {"create", "locate", "visibility", "resume", "wait"}


class TaskProviderAdapter:
    """Provider-neutral Agent-session upgrade entry.

    This small bridge delegates to a verified provider callback/object and
    never reimplements installation or migration. Provider observations,
    including ``unknown`` and ``unknown_timeout``, are returned unchanged.
    """

    def __init__(self, provider: str, delegate: Any = None, *, mode: str = "visible"):
        if not isinstance(provider, str) or not provider.strip():
            raise ValueError("provider is required")
        if mode not in {"visible", "background", "guide"}:
            raise ValueError("unsupported task provider mode")
        self.provider = provider.strip()
        self.delegate = delegate
        self.mode = mode

    def describe_upgrade_entry(self) -> Dict[str, Any]:
        return {
            "entry": "upgrade",
            "entrypoint": "upgrade",
            "provider": self.provider,
            "mode": self.mode,
            "provider_neutral": True,
            "limitations": (["不可见", "不可直接进入", "返工续接受限"] if self.mode == "background" else []),
            "evidence": {"provider": "adapter-manifest", "mode": "capability-observation"},
        }

    def invoke_upgrade(self, request: Mapping[str, Any]) -> Dict[str, Any]:
        if not isinstance(request, Mapping):
            raise TypeError("upgrade request must be a mapping")
        target = self.delegate
        method = getattr(target, "invoke_upgrade", None)
        if callable(method):
            result = method(dict(request))
        elif callable(target):
            result = target(dict(request))
        else:
            return {
                "status": "unknown",
                "provider": self.provider,
                "evidence": ["provider adapter delegate is not configured"],
            }
        if isinstance(result, Mapping):
            return dict(result)
        raise ProviderUnavailable("provider upgrade entry returned invalid result")


def _canonical_digest(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
    ).hexdigest()


class ProviderActionStore:
    """Bounded request/result mailbox between the CLI and a desktop session."""

    schema_version = 1

    def __init__(self, paths: ProjectPaths):
        self.paths = paths
        self.root = paths.resolve_vibe_path("provider-actions")

    def _directory(self, name: str) -> Path:
        directory = self.root / name
        if self.root.is_symlink() or directory.is_symlink():
            raise ValueError("provider action path may not be a symlink")
        directory.mkdir(parents=True, exist_ok=True)
        return directory

    @staticmethod
    def _atomic(path: Path, payload: Dict[str, Any]) -> None:
        if path.parent.is_symlink() or path.is_symlink():
            raise ValueError("provider action path may not be a symlink")
        encoded = (
            json.dumps(
                payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        ).encode("utf-8")
        if len(encoded) > 64 * 1024:
            raise ValueError("provider action record exceeds the size bound")
        descriptor, temporary_name = tempfile.mkstemp(
            prefix="." + path.name + ".", dir=str(path.parent)
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(str(temporary), str(path))
        finally:
            if temporary.exists():
                temporary.unlink()

    @staticmethod
    def _read(path: Path) -> Dict[str, Any]:
        if path.is_symlink() or not path.is_file():
            raise ValueError("provider action record must be a regular file")
        raw = path.read_bytes()
        if len(raw) > 64 * 1024:
            raise ValueError("provider action record exceeds the size bound")
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ValueError("provider action record is invalid") from error
        if not isinstance(value, dict):
            raise ValueError("provider action record must be an object")
        return value

    def publish_capabilities(
        self,
        adapter_id: str,
        facts: Mapping[str, Any],
        provenance: str,
    ) -> None:
        if not isinstance(adapter_id, str) or not adapter_id:
            raise ValueError("adapter id is required")
        if (
            not isinstance(facts, Mapping)
            or not facts
            or any(
                not isinstance(key, str)
                or not key.startswith(adapter_id + ".")
                or type(value) is not bool
                for key, value in facts.items()
            )
        ):
            raise ValueError("provider capability facts are invalid")
        if not isinstance(provenance, str) or not provenance:
            raise ValueError("provider capability provenance is required")
        self.root.mkdir(parents=True, exist_ok=True)
        self._atomic(
            self.root / "capabilities.json",
            {
                "schema_version": self.schema_version,
                "adapter_id": adapter_id,
                "facts": dict(facts),
                "provenance": provenance,
            },
        )

    def capabilities(self) -> Dict[str, Any]:
        value = self._read(self.root / "capabilities.json")
        if set(value) != {"schema_version", "adapter_id", "facts", "provenance"}:
            raise ValueError("provider capability schema is invalid")
        if value["schema_version"] != self.schema_version:
            raise ValueError("provider capability schema is unsupported")
        return value

    def request(
        self,
        *,
        operation: str,
        provider: str,
        run_id: str,
        issue_id: str,
        role: str,
        generation: int,
        native_tool: str,
        request: Dict[str, Any],
        sequence: int = 0,
    ) -> Dict[str, Any]:
        state = self.paths.vibe / "state.json"
        if state.is_file():
            try:
                origin = request.get("origin", "user_entry") if isinstance(request, dict) else "user_entry"
                if origin == "worker_dispatch":
                    require_child_origin(origin)
                    capability_contract = require_capability_contract(self.paths)
                    binding = request.get("child_binding")
                    required = {"parent_run_id", "plan_revision", "authorization_digest", "node_id", "role", "writer", "worktree", "branch", "allowlist", "worker_profile", "capability_contract_digest"}
                    if not isinstance(binding, dict) or not required.issubset(binding):
                        raise PermissionError("child binding is incomplete")
                    if binding.get("capability_contract_digest") != capability_contract.contract_digest:
                        raise PermissionError("child capability contract digest mismatch")
                    if binding.get("parent_run_id") != run_id or binding.get("node_id") != issue_id or binding.get("role") != role:
                        raise PermissionError("child binding identity mismatch")
                    if not (isinstance(binding.get("plan_revision"), str) and binding["plan_revision"].isdigit() and int(binding["plan_revision"]) > 0 and isinstance(binding.get("authorization_digest"), str) and len(binding["authorization_digest"]) == 64 and all(ch in "0123456789abcdef" for ch in binding["authorization_digest"].lower())):
                        raise PermissionError("child binding parent context is unverifiable")
                    profile = WorkerProfile(**binding["worker_profile"])
                    validate_child_session_binding(binding["parent_run_id"], binding["plan_revision"], binding["authorization_digest"], binding["node_id"], binding["role"], profile)
                else:
                    require_entry(self.paths, "provider:" + run_id + ":" + operation, operation)
            except (OSError, ValueError, TypeError, PermissionError) as error:
                raise ProviderUnavailable("session_gate_blocked") from error
        elif self.paths.vibe.exists():
            raise ProviderUnavailable("session_gate_blocked")
        if operation not in _PROVIDER_ACTIONS:
            raise ValueError("provider action is unsupported")
        if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 0:
            raise ValueError("provider action sequence is invalid")
        basis = {
            "operation": operation,
            "provider": provider,
            "run_id": run_id,
            "issue_id": issue_id,
            "role": role,
            "generation": generation,
            "sequence": sequence,
        }
        action_id = "action-" + _canonical_digest(basis)[:32]
        payload = {
            "schema_version": self.schema_version,
            "action_id": action_id,
            **basis,
            "native_tool": native_tool,
            "request": request,
        }
        payload["request_digest"] = _canonical_digest(payload)
        directory = self._directory("requests")
        path = directory / (action_id + ".json")
        if path.exists():
            existing = self._read(path)
            if existing != payload:
                raise ValueError("provider action request identity drift")
        else:
            self._atomic(path, payload)
        return payload

    def result(self, action_id: str) -> Optional[Dict[str, Any]]:
        path = self._directory("results") / (action_id + ".json")
        if not path.exists():
            return None
        result = self._read(path)
        request = self._read(
            self._directory("requests") / (action_id + ".json")
        )
        if (
            set(result)
            != {"schema_version", "action_id", "request_digest", "payload"}
            or result["schema_version"] != self.schema_version
            or result["action_id"] != action_id
            or result["request_digest"] != request["request_digest"]
            or not isinstance(result["payload"], dict)
        ):
            raise ValueError("provider action result is not bound to its request")
        return result["payload"]

    def complete(self, action_id: str, payload: Dict[str, Any]) -> None:
        request = self._read(
            self._directory("requests") / (action_id + ".json")
        )
        if not isinstance(payload, dict):
            raise ValueError("provider action result payload must be an object")
        self._atomic(
            self._directory("results") / (action_id + ".json"),
            {
                "schema_version": self.schema_version,
                "action_id": action_id,
                "request_digest": request["request_digest"],
                "payload": payload,
            },
        )

    def pending(self) -> List[Dict[str, Any]]:
        request_dir = self._directory("requests")
        result_dir = self._directory("results")
        result = []
        for path in sorted(request_dir.glob("action-*.json")):
            if not (result_dir / path.name).exists():
                result.append(self._read(path))
        return result

    def has_request(
        self,
        run_id: str,
        issue_id: str,
        role: str,
        operation: Optional[str] = None,
    ) -> bool:
        """Read-only check for a durable provider request in one run scope.

        Recovery uses this to distinguish a missing canonical task from an
        unresolved provider side effect.  Unlike :meth:`pending`, this probe
        does not create the mailbox directories while checking an absent
        request.
        """
        if not all(isinstance(value, str) and value for value in (run_id, issue_id, role)):
            raise ValueError("provider request identity is required")
        if operation is not None and (
            not isinstance(operation, str) or operation not in _PROVIDER_ACTIONS
        ):
            raise ValueError("provider request operation is invalid")
        if self.root.is_symlink() or (self.root.exists() and not self.root.is_dir()):
            raise ValueError("provider action path may not be a symlink")
        request_dir = self.root / "requests"
        if request_dir.is_symlink() or (request_dir.exists() and not request_dir.is_dir()):
            raise ValueError("provider request directory may not be a symlink")
        if not request_dir.is_dir():
            return False
        for path in sorted(request_dir.glob("action-*.json")):
            if path.is_symlink() or not path.is_file():
                raise ValueError("provider action request must be a regular file")
            record = self._read(path)
            if (
                record.get("run_id") == run_id
                and record.get("issue_id") == issue_id
                and record.get("role") == role
                and (operation is None or record.get("operation") == operation)
            ):
                return True
        return False


@dataclass(frozen=True)
class RepositoryTaskRouting:
    """Confirmed repository and host context for public task creation."""

    project_id: str
    host_id: str
    environment: str
    worktree: str
    branch: str

    def __post_init__(self):
        for name in ("project_id", "host_id", "worktree", "branch"):
            if not isinstance(getattr(self, name), str) or not getattr(self, name).strip():
                raise ValueError("repository routing %s is required" % name)
        if self.environment not in {"worktree", "local"}:
            raise ValueError("repository routing environment must be worktree or local")

    def target(self):
        environment = {"type": self.environment}
        if self.environment == "worktree":
            environment["startingState"] = {
                "type": "branch",
                "branchName": self.branch,
            }
        return {
            "type": "project",
            "projectId": self.project_id,
            "environment": environment,
        }


@dataclass(frozen=True)
class BackgroundTaskRouting:
    """Immutable authorized routing expected from a background launcher."""

    host: str
    worktree: str
    branch: str
    status_file: str
    handoff_file: str

    def __post_init__(self):
        for name in ("host", "worktree", "branch", "status_file", "handoff_file"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError("background routing %s is required" % name)

    def matches(self, binding: "TaskBinding") -> bool:
        return all(
            getattr(binding, name) == getattr(self, name)
            for name in ("host", "worktree", "branch", "status_file", "handoff_file")
        )


@dataclass(frozen=True)
class TaskBinding:
    provider: str
    mode: str
    role: str
    issue_id: str
    task_id: Optional[str] = None
    host: Optional[str] = None
    worktree: Optional[str] = None
    branch: Optional[str] = None
    status_file: Optional[str] = None
    handoff_file: Optional[str] = None
    cursor: Optional[str] = None
    client_thread_id: Optional[str] = None
    visible: bool = False
    limitations: Tuple[str, ...] = field(default_factory=tuple)
    allowlist: Tuple[str, ...] = field(default_factory=tuple)
    capability_contract_digest: Optional[str] = None
    successor_of: Optional[str] = None

    @property
    def thread_id(self):
        return self.task_id if self.provider == "codex-app-visible" else None

    @property
    def host_id(self):
        return self.host if self.provider == "codex-app-visible" else None

    @property
    def pending(self):
        return bool(self.client_thread_id and not self.task_id)

    def to_dict(self):
        result = self.__dict__.copy()
        result["limitations"] = list(self.limitations)
        result["allowlist"] = list(self.allowlist)
        result["capability_contract_digest"] = self.capability_contract_digest
        result["successor_of"] = self.successor_of
        if self.provider == "codex-app-visible" and self.task_id:
            result["threadId"] = self.task_id
            result["hostId"] = self.host
        return result


@dataclass(frozen=True)
class TaskUpdate:
    cursor: Optional[str]
    status: str
    payload: Mapping[str, Any] = field(default_factory=dict)

    @property
    def token(self):
        return self.cursor


@dataclass(frozen=True)
class VisibilityResult:
    visible: bool
    direct_enter: bool
    limitations: Tuple[str, ...] = ()
    source: Optional[str] = None

    def to_dict(self):
        return {
            "visible": self.visible,
            "direct_enter": self.direct_enter,
            "limitations": list(self.limitations),
            "source": self.source,
        }


class CodexAppBridge:
    """Exact structured wrapper around the public Codex App tool schemas."""

    def __init__(
        self,
        *,
        create_thread: Callable[[Mapping[str, Any]], Any],
        navigate_to_codex_page: Callable[[Mapping[str, Any]], Any],
        send_message_to_thread: Callable[[Mapping[str, Any]], Any],
        wait_threads: Callable[[Mapping[str, Any]], Any],
        list_threads: Optional[Callable[[Mapping[str, Any]], Any]] = None,
    ):
        self._create_thread = create_thread
        self._navigate = navigate_to_codex_page
        self._send = send_message_to_thread
        self._wait = wait_threads
        self._list = list_threads

    def create(self, request: Mapping[str, Any]):
        _require_keys(request, ("prompt", "target"), "create_thread")
        if not isinstance(request["prompt"], str) or not isinstance(request["target"], Mapping):
            raise ProviderUnavailable("Codex create_thread request has invalid types")
        # Keep supervisor metadata in the durable action envelope, but never
        # forward it to the native tool.  The public Codex App schema rejects
        # unknown arguments (for example issue_id, worker_profile, binding).
        public = {
            key: request[key]
            for key in ("prompt", "model", "thinking", "title")
            if key in request
        }
        target = request["target"]
        public_target = {
            key: target[key]
            for key in ("type", "projectId", "environment")
            if key in target
        }
        if isinstance(public_target.get("environment"), Mapping):
            environment = public_target["environment"]
            public_target["environment"] = {
                key: environment[key]
                for key in ("type", "startingState")
                if key in environment
            }
            if isinstance(public_target["environment"].get("startingState"), Mapping):
                starting = public_target["environment"]["startingState"]
                public_target["environment"]["startingState"] = {
                    key: starting[key]
                    for key in ("type", "branchName")
                    if key in starting
                }
        public["target"] = public_target
        return self._create_thread(public)

    def enter_or_locate(self, binding: TaskBinding):
        self._require_real(binding)
        return self._navigate({"threadId": binding.task_id})

    def resume(self, binding: TaskBinding, prompt: str):
        self._require_real(binding)
        request = {"threadId": binding.task_id, "prompt": prompt}
        if binding.host:
            request["hostId"] = binding.host
        return self._send(request)

    def wait(self, binding: TaskBinding, cursor: Optional[str], timeout_ms: int = 120000):
        self._require_real(binding)
        target = {"threadId": binding.task_id}
        if binding.host:
            target["hostId"] = binding.host
        if cursor:
            target["afterCursor"] = cursor
        raw = self._wait({"targets": [target], "timeoutMs": timeout_ms})
        if isinstance(raw, TaskUpdate):
            return raw
        if not isinstance(raw, Mapping):
            raise ProviderUnavailable("Codex wait_threads returned invalid result")
        polls = raw.get("polls")
        if not isinstance(polls, list):
            raise ProviderUnavailable("Codex wait_threads result has no polls list")
        poll = next(
            (
                item for item in polls
                if isinstance(item, Mapping)
                and isinstance(item.get("thread"), Mapping)
                and item["thread"].get("id") == binding.task_id
                and (not binding.host or item["thread"].get("hostId") == binding.host)
            ),
            None,
        )
        if poll is None:
            raise ProviderUnavailable("Codex wait_threads result has no matching poll")
        latest_turn = poll.get("latestTurn")
        turn_error = latest_turn.get("error") if isinstance(latest_turn, Mapping) else None
        if turn_error:
            status = "error"
        elif poll.get("timedOut") or raw.get("timedOut"):
            status = "timeout"
        else:
            status = _poll_status(poll)
        return TaskUpdate(
            cursor=poll.get("cursor") or cursor,
            status=status,
            payload=dict(poll),
        )

    def visibility(self, binding: TaskBinding):
        if binding.pending:
            return VisibilityResult(False, False, ("任务创建中",), "clientThreadId")
        if not binding.task_id or self._list is None:
            raise ProviderUnavailable("Codex list_threads visibility probe is unavailable")
        raw = self._list({"limit": 100})
        entries = ()
        if isinstance(raw, Mapping):
            entries = tuple(raw.get("pinnedThreads", ())) + tuple(raw.get("threads", ()))
        found = any(
            isinstance(item, Mapping)
            and item.get("id") == binding.task_id
            and (not binding.host or item.get("hostId") in (None, binding.host))
            for item in entries
        )
        return VisibilityResult(found, found, () if found else ("任务未出现在列表",), "list_threads")

    def resolve_pending(self, binding: TaskBinding):
        if not binding.pending:
            return binding
        raise ProviderPending(
            "clientThreadId remains pending; no public client-to-thread mapping is verified"
        )

    @staticmethod
    def _require_real(binding: TaskBinding):
        if binding.pending:
            raise ProviderPending("clientThreadId is pending and is not a threadId")
        if not binding.task_id:
            raise ProviderUnavailable("Codex binding has no threadId")


class VisibleTaskProvider:
    """Provider for user-visible tasks with exact identity and cursor data."""

    mode = "visible"

    def __init__(
        self,
        provider: str,
        bridge: Any = None,
        prompt_factory: Optional[Callable[[str, str, Path], str]] = None,
        routing: Optional[RepositoryTaskRouting] = None,
    ):
        self.provider = provider
        self.bridge = bridge
        self.prompt_factory = prompt_factory
        self.routing = routing

    def create(self, role: str, issue_id: str, contract_path: Path) -> TaskBinding:
        if self.bridge is None:
            raise ProviderUnavailable("visible task bridge is not configured")
        if not isinstance(self.routing, RepositoryTaskRouting):
            raise ProviderUnavailable("confirmed repository task routing is required")
        contract_path = Path(contract_path)
        prompt = (
            self.prompt_factory(role, issue_id, contract_path)
            if self.prompt_factory
            else "请执行 %s 任务 %s，合同：%s。" % (role, issue_id, contract_path)
        )
        if isinstance(self.bridge, CodexAppBridge):
            raw = self.bridge.create({"prompt": prompt, "target": self.routing.target()})
        else:
            method = getattr(self.bridge, "create", None)
            if not callable(method):
                raise ProviderUnavailable("verified visible bridge create is missing")
            raw = method(role, issue_id, contract_path)
        binding = self._binding(raw, role, issue_id)
        if not binding.task_id and not binding.client_thread_id:
            raise ProviderUnavailable("visible task creation returned no durable task identity")
        return binding

    def enter_or_locate(self, binding: TaskBinding) -> None:
        if self.bridge is None:
            raise ProviderUnavailable("visible task bridge is not configured")
        if isinstance(self.bridge, CodexAppBridge):
            self.bridge.enter_or_locate(binding)
            return
        self._invoke(binding, "enter_or_locate")

    def resume(self, binding: TaskBinding, contract_path: Path) -> None:
        if self.bridge is None:
            raise ProviderUnavailable("visible task bridge is not configured")
        contract_path = Path(contract_path)
        if isinstance(self.bridge, CodexAppBridge):
            self.bridge.resume(binding, "请继续处理合同：%s。" % contract_path)
            return
        self._invoke(binding, "resume", contract_path)

    def wait(self, binding: TaskBinding, cursor: Optional[str] = None) -> TaskUpdate:
        if self.bridge is None:
            raise ProviderUnavailable("visible task bridge is not configured")
        if isinstance(self.bridge, CodexAppBridge):
            return self.bridge.wait(binding, cursor)
        raw = self._invoke(binding, "wait", cursor)
        if isinstance(raw, TaskUpdate):
            return raw
        if isinstance(raw, Mapping):
            return TaskUpdate(raw.get("cursor"), str(raw.get("status", "unknown")), dict(raw))
        raise ProviderUnavailable("visible task wait returned invalid result")

    def visibility(self, binding: TaskBinding):
        if self.bridge is None:
            raise ProviderUnavailable("visible task bridge is not configured")
        if isinstance(self.bridge, CodexAppBridge):
            return self.bridge.visibility(binding)
        raw = self._invoke(binding, "visibility")
        if isinstance(raw, VisibilityResult):
            return raw
        if isinstance(raw, Mapping):
            return VisibilityResult(bool(raw.get("visible")), bool(raw.get("direct_enter")))
        return VisibilityResult(bool(raw), bool(raw))

    def resolve_pending(self, binding: TaskBinding):
        if isinstance(self.bridge, CodexAppBridge):
            return self.bridge.resolve_pending(binding)
        return binding

    def _invoke(self, binding: TaskBinding, method_name: str, *args):
        method = getattr(self.bridge, method_name, None)
        if not callable(method):
            raise ProviderUnavailable("verified visible bridge method missing: %s" % method_name)
        return method(binding, *args)

    def _binding(self, raw: Any, role: str, issue_id: str) -> TaskBinding:
        if isinstance(raw, TaskBinding):
            if raw.provider != self.provider or raw.mode != self.mode:
                raise ProviderUnavailable("visible bridge returned mismatched provider binding")
            if raw.role != role or raw.issue_id != issue_id:
                raise ProviderUnavailable("visible bridge returned mismatched role/issue binding")
            if raw.host != self.routing.host_id or raw.worktree != self.routing.worktree or raw.branch != self.routing.branch:
                raise ProviderUnavailable("visible bridge returned mismatched repository routing")
            return raw
        if not isinstance(raw, Mapping):
            raise ProviderUnavailable("visible task creation returned invalid binding")
        task_id = raw.get("task_id") or raw.get("threadId")
        host = raw.get("host") or raw.get("hostId") or self.routing.host_id
        if host != self.routing.host_id:
            raise ProviderUnavailable("visible task host does not match confirmed routing")
        client_thread_id = raw.get("client_thread_id") or raw.get("clientThreadId")
        return TaskBinding(
            provider=self.provider,
            mode="visible",
            role=role,
            issue_id=issue_id,
            task_id=task_id,
            host=host,
            worktree=self.routing.worktree,
            branch=self.routing.branch,
            status_file=raw.get("status_file"),
            handoff_file=raw.get("handoff_file"),
            cursor=raw.get("cursor"),
            client_thread_id=client_thread_id,
            visible=bool(task_id),
            limitations=("任务创建中",) if client_thread_id and not task_id else (),
        )


class BackgroundTaskProvider:
    mode = "background"

    def __init__(
        self,
        provider: str,
        launcher: Optional[Callable[..., Any]] = None,
        expected_routing: Optional[BackgroundTaskRouting] = None,
    ):
        self.provider = provider
        self.launcher = launcher
        self.expected_routing = expected_routing

    def with_routing(self, expected_routing: BackgroundTaskRouting):
        """Bind an immutable authorized route before task creation."""
        return BackgroundTaskProvider(self.provider, self.launcher, expected_routing)

    def create(self, role: str, issue_id: str, contract_path: Path) -> TaskBinding:
        if not isinstance(self.expected_routing, BackgroundTaskRouting):
            raise ProviderUnavailable("authorized background routing is required")
        launch = self.launcher
        if not callable(launch) and callable(getattr(launch, "launch", None)):
            launch = launch.launch
        if not callable(launch):
            raise ProviderUnavailable("verified background launcher is not configured")
        raw = launch(role, issue_id, Path(contract_path))
        if isinstance(raw, TaskBinding):
            binding = raw
        elif isinstance(raw, Mapping):
            task_id = raw.get("task_id") or raw.get("run_id") or raw.get("handle")
            if not task_id:
                raise ProviderUnavailable("background launcher returned no durable handle")
            returned_role = raw.get("role")
            returned_issue = raw.get("issue_id")
            if returned_role != role or returned_issue != issue_id:
                raise ProviderUnavailable("background launcher returned mismatched role/issue")
            if raw.get("provider") != self.provider or raw.get("mode") != self.mode:
                raise ProviderUnavailable("background launcher returned mismatched provider/mode")
            binding = TaskBinding(
                provider=self.provider,
                mode="background",
                role=role,
                issue_id=issue_id,
                task_id=str(task_id),
                host=raw.get("host"),
                worktree=raw.get("worktree"),
                branch=raw.get("branch"),
                status_file=raw.get("status_file"),
                handoff_file=raw.get("handoff_file"),
                cursor=raw.get("cursor"),
                visible=False,
                limitations=("不可见", "不可直接进入", "返工续接受限"),
            )
        else:
            raise ProviderUnavailable("background launcher returned invalid handle")
        if binding.provider != self.provider or binding.mode != self.mode:
            raise ProviderUnavailable("background launcher returned mismatched provider binding")
        if binding.role != role or binding.issue_id != issue_id:
            raise ProviderUnavailable("background launcher returned mismatched role/issue binding")
        if not binding.task_id:
            raise ProviderUnavailable("background launcher returned no durable handle")
        for name in ("host", "worktree", "branch", "status_file", "handoff_file"):
            if not getattr(binding, name):
                raise ProviderUnavailable("background binding missing routing field: %s" % name)
        if not self.expected_routing.matches(binding):
            raise ProviderUnavailable("background binding does not match authorized routing")
        return binding

    def resume(self, binding: TaskBinding, contract_path: Path) -> None:
        raise ProviderUnavailable("background task cannot be directly resumed")

    def enter_or_locate(self, binding: TaskBinding) -> None:
        raise ProviderUnavailable("background task cannot be directly entered")

    def wait(self, binding: TaskBinding, cursor: Optional[str] = None) -> TaskUpdate:
        raise ProviderUnavailable("background task has no visible wait cursor")

    def visibility(self, binding: TaskBinding):
        return VisibilityResult(False, False, binding.limitations, "background")


def _require_keys(value: Mapping[str, Any], keys, operation: str):
    missing = [key for key in keys if key not in value]
    if missing:
        raise ProviderUnavailable("%s request missing: %s" % (operation, ", ".join(missing)))


def _poll_status(poll: Mapping[str, Any]) -> str:
    thread = poll.get("thread")
    thread_status = thread.get("status") if isinstance(thread, Mapping) else None
    thread_status_type = (
        thread_status.get("type") if isinstance(thread_status, Mapping) else None
    )
    for value in (
        poll.get("status"),
        poll.get("latestTurn", {}).get("status") if isinstance(poll.get("latestTurn"), Mapping) else None,
        thread_status_type,
    ):
        if isinstance(value, str) and value:
            return value
    return "unknown"
